const config = {
  host: 'localhost',
  database: 'water_counters',
  user: 'root',
  password: ''
};

module.exports = config;