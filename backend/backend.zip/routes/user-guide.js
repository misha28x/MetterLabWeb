const express = require('express');
const mysql = require('mysql');

const router = express.Router();

module.exports = router;
